import React from 'react';
import {AbsoluteFill, Audio, Composition, Easing, Img, OffthreadVideo, Sequence, interpolate, registerRoot, staticFile, useCurrentFrame} from 'remotion';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ease = Easing.out(Easing.exp);
const navy = '#17252C';

const Screen: React.FC<{src: string; opacity?: number}> = ({src, opacity = 1}) => (
  <Img src={staticFile(src)} style={{position:'absolute', width:'100%',height:'100%',objectFit:'contain',backgroundColor:'#F4F5F6',opacity}} />
);

const Shot: React.FC<{kind: 'comandas'|'atendimento'|'cozinha'; duration?: number}> = ({kind, duration = 60}) => {
  const f = useCurrentFrame();
  const enter = interpolate(f,[0,12],[0,1],{...clamp,easing:ease});
  const drift = interpolate(f,[0,duration],[0,1],clamp);
  const pay = kind === 'atendimento' ? interpolate(f,[29,36],[0,1],clamp) : 0;
  const title = {comandas:'Mesas e comandas, em um só lugar.',atendimento:'Do pedido ao pagamento.',cozinha:'A cozinha acompanha cada pedido.'}[kind];
  return <AbsoluteFill style={{backgroundColor:navy, color:'#FFF9F1', opacity:kind === 'comandas' ? 1 : enter, overflow:'hidden'}}>
    <div style={{position:'absolute',left:-210,top:280,width:390,height:390,border:'1px solid #FF5934',borderRadius:'50%',opacity:.28,transform:`scale(${1+drift*.15})`}} />
    <div style={{position:'absolute',right:-220,top:-300,width:600,height:600,border:'1px solid #FF5934',borderRadius:'50%',opacity:.16}} />
    <Img src={staticFile('logo.svg')} style={{position:'absolute',left:48,top:29,width:174,height:37,objectFit:'contain'}} />
    <div style={{position:'absolute',right:48,top:28,fontSize:27,fontWeight:700,letterSpacing:'-.025em'}}>{title}</div>
    <div style={{position:'absolute',left:140,top:96,width:1000,height:580,background:'#F4F5F6',boxShadow:'0 24px 60px #00000066',overflow:'hidden',transformOrigin:'50% 50%',transform:`perspective(1800px) rotateY(${(1-enter)*-7}deg) rotateX(${(1-enter)*3}deg) translateY(${(1-enter)*18}px) scale(${.97+enter*.03+drift*.013})`}}>
      {kind === 'comandas' && <Screen src="comandas.png" />}
      {kind === 'atendimento' && <><Screen src="atendimento.png"/><Screen src="pagamento.png" opacity={pay}/></>}
      {kind === 'cozinha' && <Screen src="cozinha.png" />}
    </div>
    <div style={{position:'absolute',left:48,bottom:14,fontSize:11,color:'#BEC5CB'}}>Telas reais do Comanda · dados de demonstração</div>
    <div style={{position:'absolute',bottom:0,left:0,height:3,width:1280*drift,backgroundColor:'#FF5934'}} />
  </AbsoluteFill>;
};

const Closing: React.FC = () => {
  const f = useCurrentFrame();
  const opacity = interpolate(f,[0,10],[0,1],clamp);
  return <AbsoluteFill style={{backgroundColor:navy,opacity,justifyContent:'center',alignItems:'center'}}>
    <Img src={staticFile('logo.svg')} style={{width:500,filter:'brightness(0) invert(1)'}}/>
  </AbsoluteFill>;
};

const Presentation: React.FC = () => <AbsoluteFill style={{backgroundColor:navy,fontFamily:'Manrope, sans-serif'}}>
  <style>{`@font-face{font-family:Manrope;src:url('${staticFile('manrope-500.woff2')}');font-weight:500} @font-face{font-family:Manrope;src:url('${staticFile('manrope-700.woff2')}');font-weight:700}`}</style>
  <Audio src={staticFile('referencia.mp4')} />
  <Sequence durationInFrames={24}><OffthreadVideo src={staticFile('referencia.mp4')} muted style={{width:'100%',height:'100%'}} /></Sequence>
  <Sequence from={24} durationInFrames={72}><Shot kind="comandas"/></Sequence>
  <Sequence from={84} durationInFrames={72}><Shot kind="atendimento"/></Sequence>
  <Sequence from={144} durationInFrames={72}><Shot kind="cozinha"/></Sequence>
  <Sequence from={204} durationInFrames={12}><Closing/></Sequence>
  <Sequence from={216} durationInFrames={24}><OffthreadVideo src={staticFile('referencia.mp4')} startFrom={216} muted style={{width:'100%',height:'100%'}} /></Sequence>
</AbsoluteFill>;

const Root: React.FC = () => <>
  <Composition id="Comanda" component={Presentation} width={1280} height={720} fps={24} durationInFrames={240}/>
</>;
registerRoot(Root);
