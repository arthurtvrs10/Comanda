# Apresentação do Comanda por Varthex

Vídeo de 10 segundos, 1280 × 720, 24 fps, feito em React com Remotion.
O arquivo original permanece intacto. Abertura, segundo final e áudio são reutilizados da referência fornecida. A passagem para o encerramento foi refeita para remover a cozinha fictícia que ainda aparecia sob o logo.

## Edição

```powershell
npm ci
npm run studio
npm run render
```

Saída: `../outputs/apresentacao/comanda-apresentacao.mp4`.

## Montagem

| Tempo | Conteúdo |
| --- | --- |
| 0–1 s | Abertura original |
| 1–3,5 s | Grade real de mesas/comandas |
| 3,5–6 s | Atendimento e pagamento reais |
| 6–8,5 s | Cozinha KDS real |
| 8,5–9 s | Transição para a marca, sem a cozinha fictícia |
| 9–10 s | Encerramento original |

As cenas internas usam capturas existentes do repositório, com movimento de câmera e transições programados. Não são uma gravação de cliques nem mostram uma operação contínua entre comandas: os valores e números de cada captura são demonstrativos e independentes. As capturas podem anteceder os últimos ajustes do aplicativo.

## Fontes dos materiais

- Referência: `C:\Users\arthu\Downloads\gemini_generated_video_ee215803.mp4`.
- Comandas: `outputs/comanda-ajustes-neutros/comanda-grade.png`.
- Atendimento: `outputs/comanda-ajustes-neutros/comanda-claro-1180.png`.
- Pagamento: `docs/design/pagamento.png`.
- Cozinha: `docs/design/cozinha-kds.png`.
- Marca: `brand/comanda-varthex/exportacoes/logo-horizontal/negativa/svg/`.
- Fonte Manrope: `site/public/fonts/`; licença OFL copiada para `public/`.

Remotion: https://github.com/remotion-dev/remotion — observar a licença do projeto ao reutilizar a produção.
